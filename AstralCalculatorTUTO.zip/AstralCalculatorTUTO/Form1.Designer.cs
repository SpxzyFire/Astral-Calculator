﻿
namespace Tuto
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            SevenBtn = new Button();
            TxtBox = new TextBox();
            EightBtn = new Button();
            NineBtn = new Button();
            SixBtn = new Button();
            FiveBtn = new Button();
            FourBtn = new Button();
            ThreeBtn = new Button();
            TwoBtn = new Button();
            OneBtn = new Button();
            EqualBtn = new Button();
            DotBtn = new Button();
            ZeroBtn = new Button();
            ClearBtn = new Button();
            PlusBtn = new Button();
            MinusBtn = new Button();
            MultiplyBtn = new Button();
            DivideBtn = new Button();
            MinusPlusBtn = new Button();
            panel1 = new Panel();
            button2 = new Button();
            button1 = new Button();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // SevenBtn
            // 
            SevenBtn.BackColor = SystemColors.ActiveCaptionText;
            SevenBtn.ForeColor = SystemColors.ButtonHighlight;
            SevenBtn.Location = new Point(12, 126);
            SevenBtn.Name = "SevenBtn";
            SevenBtn.Size = new Size(94, 63);
            SevenBtn.TabIndex = 1;
            SevenBtn.Text = "7";
            SevenBtn.UseVisualStyleBackColor = false;
            SevenBtn.Click += SevenBtn_Click;
            // 
            // TxtBox
            // 
            TxtBox.BackColor = SystemColors.InactiveCaptionText;
            TxtBox.Font = new Font("Segoe UI", 25F);
            TxtBox.ForeColor = SystemColors.InactiveBorder;
            TxtBox.Location = new Point(12, 57);
            TxtBox.Multiline = true;
            TxtBox.Name = "TxtBox";
            TxtBox.Size = new Size(588, 63);
            TxtBox.TabIndex = 2;
            TxtBox.Text = "0";
            TxtBox.TextAlign = HorizontalAlignment.Right;
            // 
            // EightBtn
            // 
            EightBtn.BackColor = SystemColors.ActiveCaptionText;
            EightBtn.ForeColor = SystemColors.ButtonHighlight;
            EightBtn.Location = new Point(126, 126);
            EightBtn.Name = "EightBtn";
            EightBtn.Size = new Size(94, 63);
            EightBtn.TabIndex = 3;
            EightBtn.Text = "8";
            EightBtn.UseVisualStyleBackColor = false;
            EightBtn.Click += EightBtn_Click;
            // 
            // NineBtn
            // 
            NineBtn.BackColor = SystemColors.ActiveCaptionText;
            NineBtn.ForeColor = SystemColors.ButtonHighlight;
            NineBtn.Location = new Point(238, 126);
            NineBtn.Name = "NineBtn";
            NineBtn.Size = new Size(94, 63);
            NineBtn.TabIndex = 4;
            NineBtn.Text = "9";
            NineBtn.UseVisualStyleBackColor = false;
            NineBtn.Click += NineBtn_Click;
            // 
            // SixBtn
            // 
            SixBtn.BackColor = SystemColors.ActiveCaptionText;
            SixBtn.ForeColor = SystemColors.ButtonHighlight;
            SixBtn.Location = new Point(238, 211);
            SixBtn.Name = "SixBtn";
            SixBtn.Size = new Size(94, 63);
            SixBtn.TabIndex = 7;
            SixBtn.Text = "6";
            SixBtn.UseVisualStyleBackColor = false;
            SixBtn.Click += SixBtn_Click;
            // 
            // FiveBtn
            // 
            FiveBtn.BackColor = SystemColors.ActiveCaptionText;
            FiveBtn.ForeColor = SystemColors.ButtonHighlight;
            FiveBtn.Location = new Point(126, 211);
            FiveBtn.Name = "FiveBtn";
            FiveBtn.Size = new Size(94, 63);
            FiveBtn.TabIndex = 6;
            FiveBtn.Text = "5";
            FiveBtn.UseVisualStyleBackColor = false;
            FiveBtn.Click += FiveBtn_Click;
            // 
            // FourBtn
            // 
            FourBtn.BackColor = SystemColors.ActiveCaptionText;
            FourBtn.ForeColor = SystemColors.ButtonHighlight;
            FourBtn.Location = new Point(12, 211);
            FourBtn.Name = "FourBtn";
            FourBtn.Size = new Size(94, 63);
            FourBtn.TabIndex = 5;
            FourBtn.Text = "4";
            FourBtn.UseVisualStyleBackColor = false;
            FourBtn.Click += FourBtn_Click;
            // 
            // ThreeBtn
            // 
            ThreeBtn.BackColor = SystemColors.ActiveCaptionText;
            ThreeBtn.ForeColor = SystemColors.ButtonHighlight;
            ThreeBtn.Location = new Point(238, 292);
            ThreeBtn.Name = "ThreeBtn";
            ThreeBtn.Size = new Size(94, 63);
            ThreeBtn.TabIndex = 10;
            ThreeBtn.Text = "3";
            ThreeBtn.UseVisualStyleBackColor = false;
            ThreeBtn.Click += ThreeBtn_Click;
            // 
            // TwoBtn
            // 
            TwoBtn.BackColor = SystemColors.ActiveCaptionText;
            TwoBtn.ForeColor = SystemColors.ButtonHighlight;
            TwoBtn.Location = new Point(126, 292);
            TwoBtn.Name = "TwoBtn";
            TwoBtn.Size = new Size(94, 63);
            TwoBtn.TabIndex = 9;
            TwoBtn.Text = "2";
            TwoBtn.UseVisualStyleBackColor = false;
            TwoBtn.Click += TwoBtn_Click;
            // 
            // OneBtn
            // 
            OneBtn.BackColor = SystemColors.ActiveCaptionText;
            OneBtn.ForeColor = SystemColors.ButtonHighlight;
            OneBtn.Location = new Point(12, 292);
            OneBtn.Name = "OneBtn";
            OneBtn.Size = new Size(94, 63);
            OneBtn.TabIndex = 8;
            OneBtn.Text = "1";
            OneBtn.UseVisualStyleBackColor = false;
            OneBtn.Click += OneBtn_Click;
            // 
            // EqualBtn
            // 
            EqualBtn.BackColor = SystemColors.ActiveCaptionText;
            EqualBtn.ForeColor = SystemColors.ButtonHighlight;
            EqualBtn.Location = new Point(238, 371);
            EqualBtn.Name = "EqualBtn";
            EqualBtn.Size = new Size(94, 63);
            EqualBtn.TabIndex = 13;
            EqualBtn.Text = "=";
            EqualBtn.UseVisualStyleBackColor = false;
            EqualBtn.Click += EqualBtn_Click;
            // 
            // DotBtn
            // 
            DotBtn.BackColor = SystemColors.ActiveCaptionText;
            DotBtn.ForeColor = SystemColors.ButtonHighlight;
            DotBtn.Location = new Point(126, 371);
            DotBtn.Name = "DotBtn";
            DotBtn.Size = new Size(94, 63);
            DotBtn.TabIndex = 12;
            DotBtn.Text = ".";
            DotBtn.UseVisualStyleBackColor = false;
            DotBtn.Click += DotBtn_Click;
            // 
            // ZeroBtn
            // 
            ZeroBtn.BackColor = SystemColors.ActiveCaptionText;
            ZeroBtn.ForeColor = SystemColors.ButtonHighlight;
            ZeroBtn.Location = new Point(12, 371);
            ZeroBtn.Name = "ZeroBtn";
            ZeroBtn.Size = new Size(94, 63);
            ZeroBtn.TabIndex = 11;
            ZeroBtn.Text = "0";
            ZeroBtn.UseVisualStyleBackColor = false;
            ZeroBtn.Click += ZeroBtn_Click;
            // 
            // ClearBtn
            // 
            ClearBtn.BackColor = SystemColors.ActiveCaptionText;
            ClearBtn.ForeColor = SystemColors.ButtonHighlight;
            ClearBtn.Location = new Point(392, 126);
            ClearBtn.Name = "ClearBtn";
            ClearBtn.Size = new Size(208, 63);
            ClearBtn.TabIndex = 15;
            ClearBtn.Text = "Clear";
            ClearBtn.UseVisualStyleBackColor = false;
            ClearBtn.Click += ClearBtn_Click;
            // 
            // PlusBtn
            // 
            PlusBtn.BackColor = SystemColors.ActiveCaptionText;
            PlusBtn.ForeColor = SystemColors.ButtonHighlight;
            PlusBtn.Location = new Point(506, 211);
            PlusBtn.Name = "PlusBtn";
            PlusBtn.Size = new Size(94, 63);
            PlusBtn.TabIndex = 17;
            PlusBtn.Text = "+";
            PlusBtn.UseVisualStyleBackColor = false;
            PlusBtn.Click += PlusBtn_Click;
            // 
            // MinusBtn
            // 
            MinusBtn.BackColor = SystemColors.ActiveCaptionText;
            MinusBtn.ForeColor = SystemColors.ButtonHighlight;
            MinusBtn.Location = new Point(392, 211);
            MinusBtn.Name = "MinusBtn";
            MinusBtn.Size = new Size(94, 63);
            MinusBtn.TabIndex = 16;
            MinusBtn.Text = "-";
            MinusBtn.UseVisualStyleBackColor = false;
            MinusBtn.Click += MinusBtn_Click;
            // 
            // MultiplyBtn
            // 
            MultiplyBtn.BackColor = SystemColors.ActiveCaptionText;
            MultiplyBtn.ForeColor = SystemColors.ButtonHighlight;
            MultiplyBtn.Location = new Point(506, 292);
            MultiplyBtn.Name = "MultiplyBtn";
            MultiplyBtn.Size = new Size(94, 63);
            MultiplyBtn.TabIndex = 19;
            MultiplyBtn.Text = "x";
            MultiplyBtn.UseVisualStyleBackColor = false;
            MultiplyBtn.Click += MultiplyBtn_Click;
            // 
            // DivideBtn
            // 
            DivideBtn.BackColor = SystemColors.ActiveCaptionText;
            DivideBtn.ForeColor = SystemColors.ButtonHighlight;
            DivideBtn.Location = new Point(392, 292);
            DivideBtn.Name = "DivideBtn";
            DivideBtn.Size = new Size(94, 63);
            DivideBtn.TabIndex = 18;
            DivideBtn.Text = "/";
            DivideBtn.UseVisualStyleBackColor = false;
            DivideBtn.Click += DivideBtn_Click;
            // 
            // MinusPlusBtn
            // 
            MinusPlusBtn.BackColor = SystemColors.ActiveCaptionText;
            MinusPlusBtn.ForeColor = SystemColors.ButtonHighlight;
            MinusPlusBtn.Location = new Point(392, 373);
            MinusPlusBtn.Name = "MinusPlusBtn";
            MinusPlusBtn.Size = new Size(208, 63);
            MinusPlusBtn.TabIndex = 21;
            MinusPlusBtn.Text = "-/+";
            MinusPlusBtn.UseVisualStyleBackColor = false;
            MinusPlusBtn.Click += MinusPlusBtn_Click;
            // 
            // panel1
            // 
            panel1.Controls.Add(button2);
            panel1.Controls.Add(button1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(612, 51);
            panel1.TabIndex = 22;
            panel1.MouseDown += mouse_Down;
            panel1.MouseMove += mouse_Move;
            // 
            // button2
            // 
            button2.BackColor = Color.Black;
            button2.ForeColor = SystemColors.ButtonFace;
            button2.Location = new Point(406, 12);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 1;
            button2.Text = "-";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click_1;
            // 
            // button1
            // 
            button1.BackColor = Color.Black;
            button1.ForeColor = SystemColors.ButtonFace;
            button1.Location = new Point(506, 12);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 0;
            button1.Text = "X";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click_1;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, 454);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(149, 62);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 23;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Verdana", 20F, FontStyle.Bold | FontStyle.Italic);
            label1.ForeColor = Color.FromArgb(64, 64, 64);
            label1.Location = new Point(109, 475);
            label1.Name = "label1";
            label1.Size = new Size(68, 41);
            label1.TabIndex = 26;
            label1.Text = "V1";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaptionText;
            ClientSize = new Size(612, 519);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Controls.Add(panel1);
            Controls.Add(MinusPlusBtn);
            Controls.Add(MultiplyBtn);
            Controls.Add(DivideBtn);
            Controls.Add(PlusBtn);
            Controls.Add(MinusBtn);
            Controls.Add(ClearBtn);
            Controls.Add(EqualBtn);
            Controls.Add(DotBtn);
            Controls.Add(ZeroBtn);
            Controls.Add(ThreeBtn);
            Controls.Add(TwoBtn);
            Controls.Add(OneBtn);
            Controls.Add(SixBtn);
            Controls.Add(FiveBtn);
            Controls.Add(FourBtn);
            Controls.Add(NineBtn);
            Controls.Add(EightBtn);
            Controls.Add(TxtBox);
            Controls.Add(SevenBtn);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form1";
            Text = "Form1";
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

#endregion
        private Button SevenBtn;
        private TextBox TxtBox;
        private Button EightBtn;
        private Button NineBtn;
        private Button SixBtn;
        private Button FiveBtn;
        private Button FourBtn;
        private Button ThreeBtn;
        private Button TwoBtn;
        private Button OneBtn;
        private Button EqualBtn;
        private Button DotBtn;
        private Button ZeroBtn;
        private Button ClearBtn;
        private Button PlusBtn;
        private Button MinusBtn;
        private Button MultiplyBtn;
        private Button DivideBtn;
        private Button MinusPlusBtn;
        private Panel panel1;
        private Button button2;
        private Button button1;
        private PictureBox pictureBox1;
        private Label label1;
    }
}
